import javax.swing.*;
import java.awt.event.*;

public class Checkout implements ActionListener  {
    private JFrame frame;

    public Checkout(String userName, int totalCost) {
        frame = new JFrame("Top Tech--Checkout");
        frame.setSize(400, 400);
        frame.setLayout(null);

        JLabel nameLabel = new JLabel("Customer: " + userName);
        nameLabel.setBounds(30, 30, 300, 30);
        frame.add(nameLabel);

        JLabel totalLabel = new JLabel("Total Cost: " + totalCost + " ৳");
        totalLabel.setBounds(30, 70, 300, 30);
        frame.add(totalLabel);

        JButton exitButton = new JButton("Confirm");
        exitButton.setBounds(140, 110, 100, 30);
		exitButton.addActionListener(this);
		frame.add(exitButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(250, 300, 100, 30);
        logoutButton.addActionListener(this);
        frame.add(logoutButton);

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    }
	public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
            if (button.getText().equals("Logout")) {
                frame.dispose();
                new Login();
            }
			else if(button.getText().equals("Confirm")){
				frame.dispose();
			}
		}
	}
}
