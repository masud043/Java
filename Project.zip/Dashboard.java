import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

class Dashboard implements ActionListener 
{
    private JFrame frame;
    private User user;
	
	private JComboBox<String> CpuQty,GpuQty, MBQty;
	
	private Product CpuProduct;
    private Product GpuProduct;
    private Product MBProduct;

    public Dashboard(User user) {
        this.user = user;
		
		CpuProduct = new Product(10000, 10);
        GpuProduct = new Product(15000, 5);
        MBProduct = new Product(25000, 8);

        frame = new JFrame("TOP TECH SHOP");
        frame.setSize(600, 700);
        frame.setLayout(null);

        JLabel welcomeLabel = new JLabel("Welcome to TOP TECH SHOP, " + user.getName() + "!");
        welcomeLabel.setBounds(20, 10, 300, 30);
        frame.add(welcomeLabel);
        
		JLabel productsLabel = new JLabel("Products:");
        productsLabel.setBounds(20, 50, 100, 30); 
        frame.add(productsLabel);
		
		JLabel CpuLabel = new JLabel("(1)CPU:");
        CpuLabel.setBounds(20, 90, 100, 30); 
        frame.add(CpuLabel);
		
		JLabel CpuImage = new JLabel(new ImageIcon("cpu.jpg"));
        CpuImage.setBounds(20, 120, 100, 100);
        frame.add(CpuImage);
		
		JLabel CpuPrice = new JLabel("Price:"+ CpuProduct.getPrice()+" ৳");
        CpuPrice.setBounds(130, 150, 150, 30);
        frame.add(CpuPrice);
		
		JLabel CpuStock = new JLabel("Available:"+ CpuProduct.getStock());
        CpuStock.setBounds(280, 150, 100, 30);
        frame.add(CpuStock);
		
		JLabel CpuQtyLabel = new JLabel("Select Quantity:");
        CpuQtyLabel.setBounds(400, 150, 120, 30);
        frame.add(CpuQtyLabel);

        String[] qtyOptions = {"1", "2", "3", "4", "5"};
        CpuQty = new JComboBox<>(qtyOptions);
        CpuQty.setBounds(500, 150, 50, 30);
        frame.add(CpuQty);
		
		JLabel GpuLabel = new JLabel("(2)GPU:");
        GpuLabel.setBounds(20, 230, 100, 30); 
        frame.add(GpuLabel);
		
		JLabel GpuImage = new JLabel(new ImageIcon("gpu.jpg"));
        GpuImage.setBounds(20, 260, 100, 100);
        frame.add(GpuImage);
		
		JLabel GpuPrice = new JLabel("Price:"+ GpuProduct.getPrice() + "৳");
        GpuPrice.setBounds(130, 290, 150, 30);
        frame.add(GpuPrice);
		
		JLabel GpuStock = new JLabel("Available:"+ GpuProduct.getStock() );
        GpuStock.setBounds(280, 290, 100, 30);
        frame.add(GpuStock);
		
		JLabel GpuQtyLabel = new JLabel("Select Quantity:");
        GpuQtyLabel.setBounds(400, 290, 120, 30);
        frame.add(GpuQtyLabel);

        GpuQty = new JComboBox<>(qtyOptions);
        GpuQty.setBounds(500, 290, 50, 30);
        frame.add(GpuQty);

		
		JLabel MBLabel = new JLabel("(3)MotherBoard:");
        MBLabel.setBounds(20, 370, 100, 30); 
        frame.add(MBLabel);
		
		JLabel MBImage = new JLabel(new ImageIcon("motherboard.jpg"));
        MBImage.setBounds(20, 400, 100, 100);
        frame.add(MBImage);
		
		JLabel MBPrice = new JLabel("Price:"+ MBProduct.getPrice() +"৳");
        MBPrice.setBounds(130, 430, 150, 30);
        frame.add(MBPrice);
		
		JLabel MBStock = new JLabel("Available:"+ MBProduct.getStock());
        MBStock.setBounds(280, 430, 100, 30);
        frame.add(MBStock);
		
		JLabel MBQtyLabel = new JLabel("Select Quantity:");
        MBQtyLabel.setBounds(400, 430, 120, 30);
        frame.add(MBQtyLabel);

        MBQty = new JComboBox<>(qtyOptions);
        MBQty.setBounds(500, 430, 50, 30);
        frame.add(MBQty);
		
		JButton CheckoutButton = new JButton("Checkout");
        CheckoutButton.setBounds(250, 550, 100, 30); 
        CheckoutButton.addActionListener(this);
        frame.add(CheckoutButton);



        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(250, 600, 100, 30);
        logoutButton.addActionListener(this);
        frame.add(logoutButton);

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
            if (button.getText().equals("Logout")) {
                frame.dispose();
                new Login();
            }
			
			else if(button.getText().equals("Checkout")){
    int CpuQtySelected = Integer.parseInt((String) CpuQty.getSelectedItem());
    int GpuQtySelected = Integer.parseInt((String) GpuQty.getSelectedItem());
    int MBQtySelected  = Integer.parseInt((String) MBQty.getSelectedItem());

    if (CpuQtySelected > CpuProduct.getStock()) {
        JOptionPane.showMessageDialog(frame, "Exceeding Stock.");
        return;
    }
    if (GpuQtySelected > GpuProduct.getStock()) {
        JOptionPane.showMessageDialog(frame, "Exceeding Stock.");
        return;
    }
    if (MBQtySelected > MBProduct.getStock()) {
        JOptionPane.showMessageDialog(frame, "Exceeding Stock.");
        return;
    }

    int totalCost = (CpuQtySelected * CpuProduct.getPrice()) +
                    (GpuQtySelected * GpuProduct.getPrice()) +
                    (MBQtySelected * MBProduct.getPrice());

    
    new Checkout(user.getName(), totalCost);
                

            }
	    }
    }
	
}
